﻿namespace InterfaceDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PartTimeEmployee pte = new PartTimeEmployee();
            pte.Show();
        }
    }
}

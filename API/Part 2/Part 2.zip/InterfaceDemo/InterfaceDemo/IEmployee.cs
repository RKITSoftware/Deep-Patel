﻿namespace InterfaceDemo
{
    internal interface IEmployee
    {
        #region Public Methods

        void Show();

        #endregion
    }
}

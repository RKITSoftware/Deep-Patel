﻿namespace InheritanceDemo
{
    // Derived Class
    internal class VisitingEmployee : Employee
    {
        #region Public Members

        public int visitingSalary;
        public int visitingHours;

        #endregion
    }
}
